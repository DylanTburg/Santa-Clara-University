/*************************************************************
 * cache simulator main body (programming assignment #2)
 *************************************************************/
#include "cache.h"
#include <string.h>
#include <ctype.h>
#define MAX_LINE_LENGTH 200
#include <stdlib.h>
#include <time.h>



/** STUFF I ADDED **/
// LRU data stored externally
unsigned int *global_lru_stamp = NULL;
unsigned int global_lru_clock = 0;
int global_num_sets = 0;
int global_lines_per_set = 0;
//For optimal
unsigned int *global_next_use = NULL;
unsigned int global_current_next_use = 4294967295; //largest uint number to signify largest and therefore never used again



void readCache(Cache *cache, unsigned int address) {
    cache->stats->num_of_total_accesses++;

    unsigned int tag, index;
    extractTagIndex(address, cache, &tag, &index);

    CacheSet *set = &cache->sets[index];
    int num_lines = (1 << (cache->cache_size - cache->line_size));
    int lines_per_set = (!cache->assoc) ? (num_lines) : cache->assoc;

    // check for hit in all lines in the set (runs once for direct mapped)
    for (int i = 0; i < lines_per_set; i++) {
        CacheLine *line = &set->lines[i];
        if (line->valid) {
            unsigned int stored_tag = 0;
            for (int j = 0; j < line->tag->size; j++) {
                stored_tag |= getBit(line->tag, j) << j;
            }
            if (stored_tag == tag) {
                // hit
                cache->stats->num_of_hits++;
                mark_lru((int)index, i);
                //optimal
                if (cache->policy == 2) global_next_use[(int)index * global_lines_per_set + i] = global_current_next_use;
                return;
            }
        }
    }
    // no hit? inc miss and look for empty slot
    cache->stats->num_of_total_misses++;
    for (int i = 0; i < lines_per_set; i++) {
        CacheLine *line = &set->lines[i];
        if (!line->valid) {
            // compulsory miss
            cache->stats->num_of_compulsory_misses++;
            // fill line
            line->valid = true;
            for (int j = 0; j < line->tag->size; j++) {
                if ((tag >> j) & 1)
                    setBit(line->tag, j);
                else
                    clearBit(line->tag, j);
            }
            mark_lru((int)index, i);
            //optimal
            if (cache->policy == 2) global_next_use[(int)index * global_lines_per_set + i] = global_current_next_use;
            return;
        }
    }
    // No open slots? cap miss when weve cold missed 64 times
    if (cache->stats->num_of_compulsory_misses == num_lines) cache->stats->num_of_capacity_misses++;
    else cache->stats->num_of_conflict_misses++;

    //CacheLine *evicted = &set->lines[0]; //Old logic

    //NEW for many sets
    int evicted_way = pick_evicted(cache, (int)index);
    CacheLine *evicted = &set->lines[evicted_way];

    for (int j = 0; j < evicted->tag->size; j++) {
        if ((tag >> j) & 1) setBit(evicted->tag, j);
        else clearBit(evicted->tag, j);
    }
    mark_lru((int)index, evicted_way);
    //optimal
    if (cache->policy == 2) global_next_use[(int)index * global_lines_per_set + evicted_way] = global_current_next_use;
}
/* DOESNT ACTUALLY WRITE TO ANYTHING. Instead turns write into effective read so I can reuse all my read logic regarding accesses/misses and whatnot */
void writeCache(Cache *cache, unsigned int address, unsigned int value) {
    //thought I was going to have to write somewhere but Ig not. Ill keep in case I want to expand later
    readCache(cache, address);
}

void extractTagIndex(unsigned int address, Cache *cache, unsigned int *tag, unsigned int *index) {
    int offset_bits = cache->line_size;
    int num_sets = (cache->assoc == 0) ? 1 : (1 << (cache->cache_size - cache->line_size)) / cache->assoc;
    int index_bits = 0;
    int x = num_sets;
    while (x > 1) {
        index_bits++;
        x /= 2;
    }
    //update the caller mem
    *index = (address >> offset_bits) & ((1 << index_bits) - 1);
    *tag = address >> (offset_bits + index_bits);
}


void init_lru(Cache *cache) {
    int num_lines = (1 << (cache->cache_size - cache->line_size));
    global_lines_per_set = (!cache->assoc) ? num_lines : (int)cache->assoc;
    global_num_sets = (!cache->assoc) ? 1 : num_lines / (int)cache->assoc;

    global_lru_stamp = calloc(global_num_sets * global_lines_per_set, sizeof(unsigned int));
    global_lru_clock = 0;

    //For optimal
    global_next_use = calloc(global_num_sets * global_lines_per_set, sizeof(unsigned int));
    for (int i = 0; i < global_num_sets * global_lines_per_set; i++) global_next_use[i] = 4294967295;

    // random policy uses srand()
    srand((unsigned int)time(NULL));

}

void free_lru() {
    free(global_lru_stamp);
    global_lru_stamp = NULL;
    //optimal
    free(global_next_use);
    global_next_use = NULL;
}

void mark_lru(int set_index, int way) {
    if (!global_lru_stamp) return;
    global_lru_stamp[set_index * global_lines_per_set + way] = ++global_lru_clock;
}

int pick_evicted(Cache *cache, int set_index) {
    // only called when the set is full (all valid)
    //random
    if (!cache->policy) return rand() % global_lines_per_set;

    //LRU
    if (cache->policy == 1)
    {
        int evicted = 0;
        unsigned int best = global_lru_stamp[set_index * global_lines_per_set];
        for (int x = 1; x < global_lines_per_set; x++) {
            unsigned int y = global_lru_stamp[set_index * global_lines_per_set + x];
            if (y < best) {
                best = y;
                evicted = x;
            }
        }
        return evicted;
    }

    //Optimal
    if (cache->policy == 2) {
        int base = set_index * global_lines_per_set;
        int evicted = 0;
        unsigned int farthest = global_next_use[base];
        for (int x = 1; x < global_lines_per_set; x++) {
            unsigned int nu = global_next_use[base + x];
            if (nu > farthest) {   // bigger = farther in future
                farthest = nu;
                evicted = x;
            }
        }
        return evicted;
    }
}
/** END STUFF I ADDED **/






int is_comment_or_empty(const char *line) {
    return line[0] == '#' || line[0] == '\0' || isspace(line[0]);
}

unsigned int parse_number(const char *str) {
    if (strstr(str, "0x") == str) {
        return (unsigned int)strtoul(str, NULL, 16); // hexadecimal
    } else {
        return (unsigned int)atoi(str); // decimal
    }
}

Cache * parse_config(FILE *file) {
    char line[MAX_LINE_LENGTH];
    unsigned int addr_width, line_size, mem_size, cache_size, assoc, policy;
    Cache * cache = NULL;

    for (int i = 0; i < 6; i++) {
        if (fgets(line, sizeof(line), file) == NULL) {
            fprintf(stderr, "Error: Unexpected end of file while reading config\n");
            return cache;
        }

        // for debugging: printf("line %d: txt - %s\n",i,line);
        // ignoring comments or empty line
        if (is_comment_or_empty(line)) {
            i--;
            continue;
        }
        switch (i) {
            case 0: addr_width = parse_number(line); break;
            case 1: line_size = parse_number(line); break;
            case 2: mem_size = parse_number(line); break;
            case 3: cache_size = parse_number(line); break;
            case 4: assoc = parse_number(line); break;
            case 5: policy = parse_number(line); break;
        }
    }
    cache = initCache(addr_width,line_size,mem_size,cache_size, assoc,policy);
    return cache;
}

//need to pass in cache. idk why it lacked this
int parse_trace(FILE *file, Cache *my_cache) {
    char line[MAX_LINE_LENGTH];
    unsigned int num=0;

    /** Optimal handling separate because of future knowledge handling **/
    if (my_cache->policy == 2) {
        // ---- Pass 1: read trace into arrays ----
        int cap = 1000; //1000 accesses. MUST CHANGE IF TRACE CHANGES ie I have 8 accesses now? ok its 8 then.
        int len = 0;
        char *cmds = (char *)malloc(cap * sizeof(char));
        unsigned int *addrs = (unsigned int *)malloc(cap * sizeof(unsigned int));
        unsigned int *vals  = (unsigned int *)malloc(cap * sizeof(unsigned int));
        int *has_val = (int *)malloc(cap * sizeof(int));

        while (fgets(line, sizeof(line), file) != NULL) {
            // ignore comments/empty
            if (is_comment_or_empty(line)) continue;
            printf("trace #%u: %s",++num,line);
            char command;
            unsigned int address, value;
            if (sscanf(line, " %c", &command) != 1) continue;

            if (command == 'R') {
                if (sscanf(line + 1, "%x", &address) != 1) {
                    fprintf(stderr, "Error: Invalid format in READ command\n");
                    return 0;
                }
                value = 0;
                cmds[len] = 'R';
                addrs[len] = address;
                vals[len] = value;
                has_val[len] = 0;
                len++;
                sscanf(line + 1, "%x", &address);
                printf("READ: Address = 0x%x\n", address);
            }
            else {
                if (sscanf(line + 1, "%x %x", &address, &value) != 2) {
                    fprintf(stderr, "Error: Invalid format in WRITE command\n");
                    return 0;
                }
                cmds[len] = 'W';
                addrs[len] = address;
                vals[len] = value;
                has_val[len] = 1;
                len++;
                sscanf(line + 1, "%x %x", &address, &value);
                printf("WRITE: Address = 0x%x, Value = 0x%x\n", address, value);
            }
        }

        // pass 2 compute next_use[pos] per *block address*
        int offset_bits = my_cache->line_size; //log2(line_size_bytes)
        int blocks = 1 << (my_cache->addr_width - offset_bits); //number of block addresses
        int *last_seen = (int *)malloc(blocks * sizeof(int));
        unsigned int *next_use = (unsigned int *)malloc(len * sizeof(unsigned int));

        for (int b = 0; b < blocks; b++) last_seen[b] = 4294967295;
        for (int pos = len - 1; pos >= 0; pos--) {
            unsigned int block_addr = addrs[pos] >> offset_bits;
            next_use[pos] = (unsigned int)last_seen[block_addr];
            last_seen[block_addr] = pos;
        }

        // pass 3 sim forward
        for (int pos = 0; pos < len; pos++) {
            global_current_next_use = next_use[pos];
            if (cmds[pos] == 'R') readCache(my_cache, addrs[pos]);
            else writeCache(my_cache, addrs[pos], vals[pos]);
        }

        free(last_seen);
        free(next_use);
        free(cmds);
        free(addrs);
        free(vals);
        free(has_val);
        return 1;
    }
    /** END OPTIMAL HANDLING **/

    else {
        while (fgets(line, sizeof(line), file) != NULL) {

            printf("trace #%u: %s",++num,line);

            // ignoring comments or empty line
            if (is_comment_or_empty(line)) {
                continue;
            }

            char command;
            unsigned int address, value;

            // parsing command
            if (sscanf(line, "%c", &command) != 1) {
                fprintf(stderr, "Error: Invalid trace command\n");
                return 0;
            }

            // Read
            if (command == 'R') {
                if (sscanf(line + 1, "%x", &address) != 1) {
                    fprintf(stderr, "Error: Invalid address format in READ command\n");
                    return 0;
                }


                /////////////////////////////////////////////////////
                // PART 1-4
                // Implement read here
                sscanf(line + 1, "%x", &address);
                printf("READ: Address = 0x%x\n", address);
                readCache(my_cache, address);
                /////////////////////////////////////////////////////

            }
            // Write
            else if (command == 'W') {
                if (sscanf(line + 1, "%x %x", &address, &value) != 2) {
                    fprintf(stderr, "Error: Invalid format in WRITE command\n");
                    return 0;
                }

                /////////////////////////////////////////////////////
                // PART 1-4
                // Implement write here
                sscanf(line + 1, "%x %x", &address, &value);
                printf("WRITE: Address = 0x%x, Value = 0x%x\n", address, value);
                writeCache(my_cache, address, value); // <- effectively reads
                /////////////////////////////////////////////////////

            } else {
                fprintf(stderr, "Error: Unknown command '%c'\n", command);
                return 0;
            }
        }
    }
    return 1;
}


int main(int argc, char *argv[]) {

    if (argc != 3) {
        printf("Usage: cache_sim <config_file> <trace_file>\n");
        return 1;
    }

    // open configuration file
    FILE *config_file = fopen(argv[1], "r");
    if (config_file == NULL) {
        printf("Error: Could not open file '%s'\n", argv[1]);
        printf("Usage: cache_sim <config_file> <trace_file>\n");
        return 1;
    }
    printf("Successfully opened the configuration file: %s\n", argv[1]);

    // open trace file
    FILE *trace_file = fopen(argv[2], "r");
    if (trace_file == NULL) {
        printf("Error: Could not open file '%s'\n", argv[2]);
        printf("Usage: cache_sim <config_file> <trace_file>\n");
        return 1;
    }
    printf("Successfully opened the trace file: %s\n", argv[2]);


    Cache *my_cache = parse_config(config_file);
    if(my_cache==NULL) {
           printf("Configuration was not complte\n");
           return 1;
    }
    // close the config file
    fclose(config_file);

    // print out the configuration
    print_cache_config(my_cache);
    //ADDED
    init_lru(my_cache);
    //ADDED
    // parse trace | updated
    parse_trace(trace_file, my_cache);
    // close the trace file
    fclose(trace_file);
    // print out the statistics
    my_cache->stats->hit_rate =  100 * ((long double)(my_cache->stats->num_of_hits) / (long double)(my_cache->stats->num_of_total_accesses));
    print_stats(my_cache->stats);
    // freeing cache
    freeCache(my_cache);
    //ADDED
    free_lru();
    //ADDED
    return 0;
}





