module traffic_light_controller (
	input [1:0] mode, // 00 = emergency | 01 = normal | 10 = traffic | 11 = auto
	input clk, rst, xl, mode_ti, hold_a, //x1 is priority; a_hold is to stop auto counter
	output reg y10, y11, y12, y20, y21, y22, p1, p2
	);

	reg clk10, clk20, clk40, auto_n, mode_t;
	reg [1:0] set_mode;
	reg [2:0] count;
	reg [3:0] clk_count;
	parameter [1:0] EM = 2'b00, NO = 2'b01, TR = 2'b10, AU = 2'b11;

	wire n10, n11, n12, n20, n21, n22, n1, n2;
	wire t10, t11, t12, t20, t21, t22, t1, t2;
	wire e10, e11, e12, e20, e21, e22, e1, e2;

	normal dut_n(clk, rst, clk10, clk20, clk40, n10, n11, n12, n20, n21, n22, n1, n2);
	traffic_increased dut_t (clk, ~rst, xl, mode_t&&(mode==AU) || mode_ti, t10, t11, t12, t20, t21, t22, t1, t2);
	emergency dut_e (clk, rst, e10, e11, e12, e20, e21, e22, e1, e2);

	
	//Normal_Mode clk management
	always @ (negedge clk) begin
		if(rst) begin clk10 <= 0; clk_count <= 0; end
		else begin
			clk_count <= clk_count == 4'd9 ? 0 : clk_count +1;
			clk10 <= clk_count == 4'd9 ? ~clk10 : clk10;
		end
	end

	always @(negedge clk10) begin
		if(rst) clk20 <=0;
		else clk20 <= ~clk20;
	end

	always @(negedge clk20) begin
		if(rst) clk40 <=0;
		else clk40 <= ~clk40;
	end

	

	always @ (negedge clk40 or posedge rst) begin
		if (rst) count <= 3'b000;
		else begin
			if(xl) begin
				count <= count == 3'b011 || (hold_a & ~mode) ? count : count +1;
			end
			else begin
				count <= count == 3'b101 || (hold_a & ~mode) ? count : count-1;
			end
		end
	end

	always @ (count) begin
		auto_n <= 1; mode_t <= 0;
		case(count)
			3'b101: begin auto_n <= 0; mode_t <= 1; end
			3'b110: auto_n <= 0;
			3'b111: auto_n <= 1;
			3'b000: auto_n <= 1;
			3'b001: auto_n <= 1;
			3'b010: auto_n <= 0;
			3'b011: begin auto_n <= 0; mode_t <= 1; end
		endcase
	end

	// Make a simpler mode so the mux doesn't generate multiple layers
	always @ (*)
		set_mode = (mode == 2'b00) ? EM : (mode == 2'b01) ? NO : (mode == 2'b10) ? TR : (mode == 2'b11) ? ((auto_n == 1'b0) ? TR : NO) : 2'b00;

	always @ (*) begin
		case(set_mode)
			EM: begin
				y10 = e10;
				y11 = e11;
				y12 = e12;
				y20 = e20;
				y21 = e21;
				y22 = e22;
				p1 <= e1;
				p2 <= e2;
			end
			NO: begin
				y10 = n10;
				y11 = n11;
				y12 = n12;
				y20 = n20;
				y21 = n21;
				y22 = n22;
				p1 <= n1;
				p2 <= n2;
			end
			TR: begin
				y10 = t10;
				y11 = t11;
				y12 = t12;
				y20 = t20;
				y21 = t21;
				y22 = t22;
				p1 <= t1;
				p2 <= t2;
			end
			default: begin
				y10 = 1'b0;
				y11 = 1'b0;
				y12 = 1'b0;
				y20 = 1'b0;
				y21 = 1'b0;
				y22 = 1'b0;
				p1 <= 1'b0;
				p2 <= 1'b0;
			end
		endcase
	end


endmodule

