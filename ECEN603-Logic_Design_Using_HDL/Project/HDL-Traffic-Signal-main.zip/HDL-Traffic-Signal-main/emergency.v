module emergency(
	input clk, rst,
	output reg t10, t11, t12, //Light 1: red, yellow, green
	output reg t20, t21, t22, //Light 2: red, yellow, green
	output reg p1, p2
);

always @ (posedge clk) begin
	t10 <= 0; t12 <= 0; t20 <= 0; t22<= 0; p1 <= 0; p2 <= 0;
		if (rst) begin t11 <= 0; t21 <=0; end
		else begin t11 <= ~t11; t21 <= ~t21; end
end
	
endmodule

