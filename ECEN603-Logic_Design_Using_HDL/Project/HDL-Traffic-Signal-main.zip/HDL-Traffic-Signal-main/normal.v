module normal (
	input clk, rst, x1, x2, x3,
	output reg t10, t11, t12, //Light 1: red, yellow, green
	output reg t20, t21, t22, //Light 2: red, yellow, green
	output reg p1, p2
	);

	reg [2:0] next_state, current_state;
	parameter [2:0] GREEN = 3'b000, FLICKER = 3'b001, RED = 3'b010, YELLOW = 3'b100,  RED_YELLOW = 3'b110;

	always @ (posedge clk) begin
		if (rst) current_state <= GREEN;
		else current_state <= next_state;
	end
	
	always @ (*)
	begin
		case({x3,x2,x1})
		3'b000: next_state = GREEN;
		3'b001: next_state = GREEN;
		3'b010: next_state = FLICKER;
		3'b011: next_state = YELLOW;
		3'b100: next_state = RED;
		3'b101: next_state = RED;
		3'b110: next_state = RED;
		3'b111: next_state = RED_YELLOW;
		default: next_state = next_state;
		endcase
	end

	always @ (*) begin
		t10 = 0; t11 = 0; t12 = 0; t20 = 0; t21 = 0; t22 = 0; p1=0; p2=0;
		case(current_state)
		GREEN: begin t12 = 1; t20 = 1; p2 = 1;
		end
		FLICKER: begin t12 = clk; t20 = 1; t21=1;  p2 = clk;
		end
		YELLOW: begin t11 = 1; t20 = 1; t21 = 1;
		end
		RED_YELLOW: begin t10 = 1; t11 = 1; t22 = clk; p1 = clk;
		end
		RED: begin t10 =1; t22 = 1; p1 = 1;
		end
		endcase
	end

endmodule

