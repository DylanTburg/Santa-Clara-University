module tb_controller;
	reg clk, rst, xl, mode_t, hold_a;
	wire t1_red, t1_yellow, t1_green;
	wire t2_red, t2_yellow, t2_green;
	wire p1_green, p2_green;

	reg [1:0] mode;

	traffic_light_controller dut(mode, clk, rst, xl, mode_t, hold_a,
	t1_red, t1_yellow, t1_green,
	t2_red, t2_yellow, t2_green,
	p1_green, p2_green
	);

	initial clk = 0;
	always #1 clk = ~clk;

	initial begin
		rst = 0; xl = 0; mode_t = 0; mode = 2'b00; hold_a = 1;
		#0.5
		rst=1; 
		#10
		rst=0;
		$display("EMERGENCY Mode Test");
		#10

		mode = 2'b01;
		$display("NORMAL Mode Test");
		#100
		
		mode = 2'b10;
		$display ("TRAFFIC Mode Test");

		$display("Test 1: 75/25, T1 priority ");
		xl = 0; mode_t = 0;
		#160;

		$display("Test 2: 75/25, T2 priority ");
		xl = 1; mode_t = 0;
		#160;

		$display("Test 3: 62.5/37.5, T1 priority ");
		xl = 0; mode_t = 1;
		#160;

		$display("Test 4: 62.5/37.5, T2 priority ");
		xl = 1; mode = 1;
		#160;

		mode = 2'b11; xl = 1;
		$display("AUTO TEST");
		#200
		hold_a = 0;
		#200
		xl = 0;
		#400
		hold_a = 1; xl = 1;
		#300
		hold_a = 0;
		#500
		
		$display("DONE");
		$finish;

	end

	always @ (dut.dut_n.current_state) begin :normal
		if(~mode[0] || (mode == 2'b11 && ~dut.auto_n)) disable normal;
		if(mode == 2'b11) $display("NORMAL Count:%d", dut.count);
		#0.5
		case (dut.dut_n.current_state)
			3'b000: $display("T=%0t  S_T1_GREEN  | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
				$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'b001: $display("T=%0t  S_T1_FLICKER | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'b010: $display("T=%0t  S_T1_RED     | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'b100: $display("T=%0t  S_T1_YELLOW  | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'b110: $display("T=%0t  S_T1_RED_YELLOW | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
		endcase
	end

	always @ (dut.dut_t.curr_state) begin :traffic
		if(~mode[1] || (mode == 2'b11 && dut.auto_n)) disable traffic;
		if(mode == 2'b11) $display("TRAFFIC Count:%d", dut.count);
		#0.5
		case (dut.dut_t.curr_state)
			3'd0: $display("T=%0t  S_T1_GREEN  | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
				$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'd1: $display("T=%0t  S_T1_YELLOW | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'd2: $display("T=%0t  S_T2_RY     | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'd3: $display("T=%0t  S_T2_GREEN  | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'd4: $display("T=%0t  S_T2_YELLOW | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'd5: $display("T=%0t  S_T1_RY     | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
		endcase
	end
	
	always @ (dut.dut_e.t11) begin
		if(mode == 2'b00)
		$display("T=%0t  EMERGENCY  | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
				$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
	end

endmodule
