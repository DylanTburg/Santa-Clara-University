module tb_normal();
	reg clk, rst, x0, x1, x2;
	wire t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green;
	
	normal dut(clk, rst,x0,x1,x2, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);

	always #1 clk = ~clk;
	always #10 x0 = ~x0;
	always #20 x1 = ~x1;
	always #40 x2 = ~x2;

	initial begin
		x0 = 0;
		x1 = 0;
 		x2 = 0;
		clk = 0;
		rst = 1;
		
		#1

		rst = 0;

		#99 
		$finish;
	end

	always @ (dut.current_state) begin
		@ (posedge clk);
		case (dut.current_state)
			3'b000: $display("T=%0t  S_T1_GREEN  | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
				$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'b001: $display("T=%0t  S_T1_FLICKER | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'b010: $display("T=%0t  S_T1_RED     | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'b100: $display("T=%0t  S_T1_YELLOW  | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'b110: $display("T=%0t  S_T1_RED_YELLOW | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
		endcase
	end

endmodule
