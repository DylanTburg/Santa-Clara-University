module tb_traffic_increased;
	reg clk, rst_n, xl, mode;
	wire t1_red, t1_yellow, t1_green;
	wire t2_red, t2_yellow, t2_green;
	wire p1_green, p2_green;

	traffic_increased dut (
		.clk(clk),
		.rst_n(rst_n),
		.xl(xl),
		.mode(mode),
		.t1_red(t1_red),
		.t1_yellow(t1_yellow),
		.t1_green(t1_green),
		.t2_red(t2_red),
		.t2_yellow(t2_yellow),
		.t2_green(t2_green),
		.p1_green(p1_green),
		.p2_green(p2_green)
  	);

	initial clk = 0;
	always #0.5 clk = ~clk;

	initial begin
		rst_n = 0; xl = 0; mode = 0;
		#4;
		rst_n = 1;

		$display("Test 1: 75/25, T1 priority ");
		xl = 0; mode = 0;
		#160;

		$display("Test 2: 75/25, T2 priority ");
		xl = 1; mode = 0;
		#160;

		$display("Test 3: 62.5/37.5, T1 priority ");
		xl = 0; mode = 1;
		#160;

		$display("Test 4: 62.5/37.5, T2 priority ");
		xl = 1; mode = 1;
		#160;

		$display("Simulation complete ");
		$finish;
	end

  	always @(dut.curr_state) begin
		case (dut.curr_state)
			3'd0: $display("T=%0t  S_T1_GREEN  | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
				$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'd1: $display("T=%0t  S_T1_YELLOW | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'd2: $display("T=%0t  S_T2_RY     | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'd3: $display("T=%0t  S_T2_GREEN  | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'd4: $display("T=%0t  S_T2_YELLOW | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
			3'd5: $display("T=%0t  S_T1_RY     | T1=%b%b%b | T2=%b%b%b | P1=%b P2=%b",
			    	$time, t1_red, t1_yellow, t1_green, t2_red, t2_yellow, t2_green, p1_green, p2_green);
		endcase
	end

endmodule

