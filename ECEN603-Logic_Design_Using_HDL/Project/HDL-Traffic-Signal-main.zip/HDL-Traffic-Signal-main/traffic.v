module traffic_increased (
	input clk,
	input rst_n,
	input xl, // if 0, T1 gets priority | if 0, T2 does
	input mode, //75,25 or 62.5,37.5
	output reg t1_red,
	output reg t1_yellow,
	output reg t1_green,
	output reg t2_red,
	output reg t2_yellow,
	output reg t2_green,
	output reg p1_green,
	output reg p2_green
);

	// state encoding
	localparam [2:0]  S_T1_GREEN = 3'd0,
		    	  S_T1_YELLOW = 3'd1,
		    	  S_T2_RY = 3'd2,
		    	  S_T2_GREEN = 3'd3,
		    	  S_T2_YELLOW = 3'd4,
		    	  S_T1_RY = 3'd5;

	// phase durations
	localparam [5:0] RY_DUR = 6'd2, YEL_DUR = 6'd2;

	reg [2:0] curr_state, next_state;
	reg [5:0] cnt, cnt_next;
	reg [5:0] t1_grn_dur, t2_grn_dur;
	reg [5:0] t1_grn_sel, t2_grn_sel;

	// duration selector (.75,.25 or .625,.375 * 80 - 4 for each)
	always @(*) begin
		case ({mode, xl})

			2'b00: begin 
				t1_grn_sel = 6'd56; 
				t2_grn_sel = 6'd16; 
			end

			2'b01: begin 
				t1_grn_sel = 6'd16; 
				t2_grn_sel = 6'd56; 
			end

			2'b10: begin 
				t1_grn_sel = 6'd46; 
				t2_grn_sel = 6'd26; 
			end

			2'b11: begin 
				t1_grn_sel = 6'd26; 
				t2_grn_sel = 6'd46; 
			end

			default: begin
				t1_grn_sel = 6'd56; 
				t2_grn_sel = 6'd16; 
			end

		endcase
	end

	always @(posedge clk or negedge rst_n) begin
		if (!rst_n) begin
			t1_grn_dur <= 6'd56;
			t2_grn_dur <= 6'd16;

			curr_state <= S_T1_RY;
			cnt <= 6'd0;
		end 
		else if (curr_state == S_T1_RY && cnt == RY_DUR - 1'b1) begin
			t1_grn_dur <= t1_grn_sel;
			t2_grn_dur <= t2_grn_sel;
			curr_state <= next_state;
			cnt <= cnt_next;
		end
		else begin
			curr_state <= next_state;
			cnt <= cnt_next;
		end
	end

	//next-states
	always @(*) begin
		next_state = curr_state;
		cnt_next = cnt + 6'd1;
		case (curr_state)
			S_T1_GREEN: begin
				if (cnt == t1_grn_dur - 1'b1) begin
					next_state = S_T1_YELLOW;
					cnt_next = 6'd0;
				end
			end

			S_T1_YELLOW: begin
				if (cnt == YEL_DUR - 1'b1) begin
					next_state = S_T2_RY;
					cnt_next = 6'd0;
				end
			end

			S_T2_RY: begin
				if (cnt == RY_DUR - 1'b1) begin
					next_state = S_T2_GREEN;
					cnt_next = 6'd0;
				end
			end

			S_T2_GREEN: begin
				if (cnt == t2_grn_dur - 1'b1) begin
					next_state = S_T2_YELLOW;
					cnt_next = 6'd0;
				end
			end

			S_T2_YELLOW: begin
				if (cnt == YEL_DUR - 1'b1) begin
					next_state = S_T1_RY;
					cnt_next = 6'd0;
				end
			end

			S_T1_RY: begin
				if (cnt == RY_DUR - 1'b1) begin
					next_state = S_T1_GREEN;
					cnt_next = 6'd0;
				end
			end

			default: begin
				next_state = S_T1_RY;
				cnt_next = 6'd0;
			end
		endcase
	end

	// outputs
	always @(*) begin
		t1_red = 1'b0;
		t1_yellow = 1'b0;
		t1_green = 1'b0;
		t2_red = 1'b0;
		t2_yellow = 1'b0;
		t2_green = 1'b0;
		p1_green = 1'b0;
		p2_green = 1'b0;
		case (curr_state)

			S_T1_GREEN: begin
				t1_green = (next_state == S_T1_YELLOW) ? clk : 1'b1;
				t2_red = 1'b1;
				p2_green = (next_state == S_T1_YELLOW) ? clk : 1'b1;
			end

			S_T1_YELLOW: begin
				t1_yellow = 1'b1;
				t2_red = 1'b1;
				p2_green = 1'b1;
			end

			S_T2_RY: begin
				t1_red = 1'b1;
				t2_red = 1'b1;
				t2_yellow = 1'b1;
			end

			S_T2_GREEN: begin
				t1_red = 1'b1;
				t2_green = (next_state == S_T2_YELLOW) ? clk : 1'b1;
				p1_green = (next_state == S_T2_YELLOW) ? clk :1'b1;
			end

			S_T2_YELLOW: begin
				t1_red = 1'b1;
				t2_yellow = 1'b1;
				p1_green = 1'b1;
			end

			S_T1_RY: begin
				t1_red = 1'b1;
				t1_yellow = 1'b1;
				t2_red = 1'b1;
			end

			default: begin
				t1_red = 1'b1;
				t2_red = 1'b1;
			end

		endcase
	end

endmodule

