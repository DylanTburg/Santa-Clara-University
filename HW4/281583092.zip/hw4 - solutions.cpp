// Starter code for CSCI 163 HW4, due 11:59pm Friday, 10/25/24

#include <iostream>
#include <fstream>
#include <cmath>
#include <cfloat>
using namespace std;

class Point { // a simple struct-like class that does the job
public:
	double x;
	double y;
};

void readPoints(string file, Point*& inputs, int& n); // setup is done for you
double dist(Point pi, Point pj); // utility function is done for you
double bfClosestPair(Point* inputs, int n); // TODO: IMPLEMENT THIS
void sortBy(Point *inputs, int n, bool x); // D&Q sorting is done for you
double dqClosestPair(Point* inputs, int n); // setup for D&Q cp is done for you
double cp(Point *px, Point *pY, int n); // TODO: IMPLEMENT THIS

int main() {
	// readPoints determines n from file contents, allocates a dynamic array,
	// and populates the array with points corresponding to file contents
	Point *inputs;
	int n = 0;
	readPoints("points.txt", inputs, n); // write your own data files to test

	// Check that your two algorithms produce the same answer
	cout << "Answer: " << bfClosestPair(inputs, n) << endl;
	cout << "Answer: " << dqClosestPair(inputs, n) << endl;

	return 0;
}

// allocates space for points array, populates with contents from specified file
void readPoints(string filename, Point*& inputs, int& n) {
	double x, y;
	ifstream fin(filename);
	while (fin >> x >> y) n++;
	fin.clear();
	fin.seekg(0);
	inputs = new Point[n];
	for (int i=0; i<n; i++) {
		fin >> x >> y;
		inputs[i].x = x;
		inputs[i].y = y;
	}
	fin.close();
}

// returns euclidean distance of two points in the plane
double dist(Point pi, Point pj) {
	return sqrt((pi.x-pj.x)*(pi.x-pj.x)+(pi.y-pj.y)*(pi.y-pj.y));
}

// checks distance between every pair of points, returning the min
double bfClosestPair(Point *inputs, int n) {
	// BRUTE FORCE: Check distance between every pair, keeping track of min.
	//DBL_MAX is the closest you can get to infinity
	double minDist = DBL_MAX;
	int i, j;
	for(i=0; i < n; i++)
    {
        for(j=i+1; j < n; j++)
        {
            double x = dist(inputs[i], inputs[j]);
            if(x < minDist)
            {
                minDist=x;
            }
        }
    }
    return minDist;
}

// sorts points array by x and y and calls D&Q algorithm
double dqClosestPair(Point *byX, int n) {
	// sort inputs by x
	sortBy(byX, n, true);
	// copy input array and sort by y
	Point *byY = new Point[n];
	for (int i=0; i<n; i++) {
		byY[i]=byX[i];
	}
	sortBy(byY, n, false);
	// make first call to recursive alg and return numeric result
	return cp(byX,byY,n);
}


double cp(Point *pX, Point *pY, int n) {
	// BASE CASE: When do you want recursion to stop?
	// Hint: Constant time brute force once you get to n<= a small constant so
	// you don't have to figure out what to return if there's only one point.

	//pX is in order for least to greatest x coord. pY is in order for least to greatest y coord

    if (n <= 3)
        return bfClosestPair(pX, n);
	// RECURSION PREP: Splice pX and pY into equal sized halves for recursion.
	// Hint: Allocate new dynamic arrays via, eg Point* pXLeft = new Point[n/2],
	// populate them appropriately, and don't worry about memory leaks.
    int mid = n/2;
    Point midPoint = pX[mid];
    Point *pXLeft = new Point[mid]; //left point x array
    Point *pXRight = new Point[n-mid]; //right point x array
    Point *pYLeft = new Point[mid]; //left point y array
    Point *pYRight = new Point[n-mid]; //right point  y array
    int left = 0;
    int right = 0;
    int i;
    int j;
    //theta(n)
    for(i=0; i< mid; i++)
    {
        pXLeft[i] = pX[i];
    }
    for(i=mid; i< n; i++)
    {
        pXRight[i-mid] = pX[i];
    }
    //theta(n)
    for(i=0; i < n; i++) //puts points in left or right array y cord array based on position relative to mid x coordinate
    {
        if(pY[i].x <= midPoint.x) //changing < to <= fixed the bug for 40. new limit
        {
            pYLeft[left] = pY[i];
            left++;
            if(left >= mid) break; // shouldnt need this but just in case
        }
        else
        {
            pYRight[right] = pY[i];
            right++;
            if(right >= n-mid) break; // shouldnt need this but just in case
        }
    }
	// RECURSION: Call cp twice with appropriate arguments to find the closest
	// distance between points on the left and on the right, respectively.
	// (Call the min of these two quantities d.)
	// 2T(n/2) + theta(n)= theta(nlogn)
    double leftDist = cp(pXLeft, pYLeft, mid); //stores smallest distance on left side
    double rightDist = cp(pXRight, pYRight, n - mid); //stores smallest distance on right side
    double d = min(leftDist, rightDist); //finds the smallest between the two
	// NON-RECURSIVE WORK: 1/ Prepare a subarray sorted by y for points with
	// x-coordinates within a d-band of the midpoint. 2/ Scan the subarray,
	// and for each point in the band, compare its distance to the distance of
	// everything that comes later until its y-coordinate is more than d away,
	// keeping track of the minimum distance found. 3/ Return the minimum of d
	// and anything found during non-recursive work.
    Point *strip = new Point[n]; //Now it's time for the middle strip
    int stripCount = 0;
    //theta(n)
    for(i=0; i < n; i++)
    {
        if (fabs(pY[i].x - midPoint.x) < d) //fabs = float absolute value. maybe <=
        {
            strip[stripCount] = pY[i]; //if points are less than d distance away from midPoint, they are added to the strip
            stripCount++;
        }
    }
    double minStripDist = d;
    //theta(m^2) where m is the number of strip points which is max 6 so it's really theta(1)
    for(i=0; i < stripCount; i++) //now we just check the strip for the smallest distance among points in the strip
    {
        for(j=i+1; j < stripCount && ((strip[j].y - strip[i].y) < d); j++)
        {
            double dis = dist(strip[i], strip[j]);
            if (dis < minStripDist)
            {
                minStripDist = dis;
            }
        }
    }
    delete[] pXLeft;
    delete[] pXRight;
    delete[] pYLeft;
    delete[] pYRight;
    delete[] strip;
	return min(d, minStripDist); //return the smallest value between smallest strip distance and smallest left/right distance
    //theta(n)+theta(nlogn)+theta(n)+theta(1)=theta(nlogn)
}


void sortBy(Point *inputs, int n, bool x) {
	// BASE CASE
	if (n<=1) return;
	// RECURSION
	int mid=n/2; // size of left half = first index of right half
	sortBy(inputs, mid, x);
	sortBy(inputs+mid, n-mid, x);
	// NON-RECURSIVE MERGE
	Point *temp = new Point[n];
	int l=0, r=mid;
	// Iterate through each half of inputs, copying into temp in sorted order
	for (int i=0; i<n; i++) {
		// Note: This complex condition employs short-circuit evaluation
		// and the ternary operator (cond ? value if true | value if false),
		// and it sorts by x or y depending on whether parameter x==true.
        if (l < mid && (r >= n ||
        	(x ? inputs[l].x < inputs[r].x : inputs[l].y < inputs[r].y))) {
			temp[i] = inputs[l++];
		} else {
			temp[i] = inputs[r++];
		}
	}
	// Copy from temp back to inputs and delete temp
	for (int i=0; i<n; i++) {
		inputs[i] = temp[i];
	}
	delete [] temp;
}

