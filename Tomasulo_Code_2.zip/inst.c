#include "inst.h"
#include <stdio.h>

INST inst[NUM_OF_INST]; /* instruction array */
/******************************
* instruction initialization
******************************/
void init_inst()
{
  inst[0].num=1; inst[0].op=ST; inst[0].rd=6; inst[0].rs=2; inst[0].rt=34; // st r6,34(r2)
  inst[1].num=2; inst[1].op=LD; inst[1].rd=2; inst[1].rs=3; inst[1].rt=45; // ld r2,45(r3)
  inst[2].num=3; inst[2].op=MUL; inst[2].rd=0; inst[2].rs=6; inst[2].rt=4; // mul r0, r6, r4
  inst[3].num=4; inst[3].op=SUB; inst[3].rd=0; inst[3].rs=2; inst[3].rt=6; // sub r0, r2, r6
  inst[4].num=5; inst[4].op=DIV; inst[4].rd=12; inst[4].rs=6; inst[4].rt=0; // div r12, r6, r0
  inst[5].num=6; inst[5].op=ADD; inst[5].rd=6; inst[5].rs=8; inst[5].rt=0; // add r6, r8, r0
  return;
}

/* print an instruction */
void print_inst(INST ins) {
  printf("I#%d\t",ins.num);
  if(ins.op==ADD) printf("add\tr%d,r%d,r%d\n",ins.rd,ins.rs,ins.rt);
  else if(ins.op==SUB) printf("sub\tr%d,r%d,r%d\n",ins.rd,ins.rs,ins.rt);
  else if(ins.op==MUL) printf("mul\tr%d,r%d,r%d\n",ins.rd,ins.rs,ins.rt);
  else if(ins.op==DIV) printf("div\tr%d,r%d,r%d\n",ins.rd,ins.rs,ins.rt);
  else if(ins.op==LD) printf("ld\tr%d,%d(r%d)\n",ins.rd,ins.rt,ins.rs);
  else if(ins.op==ST) printf("st\tr%d,%d(r%d)\n",ins.rd,ins.rt,ins.rs); //initially said ld instead of st
  else printf("unknown\n");
}

void print_program() {
  int i=0;
  for(i=0;i<NUM_OF_INST;i++) print_inst(inst[i]);
}


