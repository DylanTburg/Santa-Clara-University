#include <stdio.h>
#include <stdlib.h>
#include "arch.h"


/*******************************
main
*******************************/
int main()
{
  int i,j;
  int done = 0;
  int cycle = 0;
  int num_issued_inst = 0;

  init_inst();
  init_fu();

  printf("============== TEST INSTRUCTION SEQUENCE ===========\n");
  print_program();

  init_rs();	// initialize RS entries
  init_regs();	// initalize registers
  init_mem();	// initialize memory

  printf("* CYCLE %d (initial state)\n",cycle);
  print_rs();	// print initial RS state
  print_regs();	// print initial register state

  /* simulation loop main */
  while(!done){

    /* increment the cycle */
    cycle++;

    /********************************
     *     Step III: Write result
     ********************************/
    //find first RS thats ready then compute its result and free FU
    //broadcast result and update waiting RS ops and registers
    // for store, write to mem
    //clear RS entry once wb finishes
    int chosen = -1; //index of first RS that is ready
    int tag = -1;
    int result = 0;
    // select first ready RS (lowest index)
    for (i = 0; i < NUM_RS_ENTRIES; i++) {
        RS *r = &rs_array[i];
        if (r->is_busy && r->is_result_ready && chosen == -1) {
            chosen = i;
            tag = r->id;
        }
    }

    // perform the write/commit
    if (chosen >= 0) {
        RS *r = &rs_array[chosen];

        if (r->op == ST) {
            int addr = r->A;
            if (addr < 0) addr = 0;
            if (addr >= MEM_SIZE) addr = MEM_SIZE - 1;
            mem_arr[addr] = r->Vk; //was Vj
            is_mem_available = true;
            reset_rs_entry(r);
        }
        else {
            // compute result / free FU for other ops
            if (r->op == LD) {
                int addr = r->A;
                if (addr < 0) addr = 0;
                if (addr >= MEM_SIZE) addr = MEM_SIZE - 1;
                result = mem_arr[addr];
                is_mem_available = true;
            }
            else if (r->op == ADD || r->op == SUB) {
                if (r->op == ADD) result = r->Vj + r->Vk;
                else result = r->Vj - r->Vk;
                is_add_available = true;
            }
            else if (r->op == MUL || r->op == DIV) {
                if (r->op == MUL) result = r->Vj * r->Vk;
                else result = (r->Vk == 0 ? 0 : (r->Vj / r->Vk)); //avoid divide by 0 err
                is_mul_available = true;
            }

            // CDB broadcast to RS operands
            for (int j = 0; j < NUM_RS_ENTRIES; j++) {
                RS *w = &rs_array[j];
                if (w->is_busy) {
                    if (w->Qj == tag) {
                        w->Qj = 0;
                        w->Vj = result;
                    }
                    if (w->Qk == tag) {
                        w->Qk = 0;
                        w->Vk = result;
                    }
                }
            }
            // Register file wb
            for (int reg_idx = 0; reg_idx < NUM_REGS; reg_idx++) {
                if (regs[reg_idx].Qi == tag) { //only wb if this RS still owns the reg
                    regs[reg_idx].val = result;
                    regs[reg_idx].Qi  = 0;
                }
            }
            reset_rs_entry(r);
        }
    }

     /********************************
      *     Step II: Execute
      ********************************/
    // if running, tick down and mark ready for wb when 0, but dont free fu
    // not running and not ready? start execution if ops are ready and FU is free
    // if ready do nothing
    for(i=0;i<NUM_RS_ENTRIES;i++) {
        RS *r = &rs_array[i];
        if(r->is_busy) {
            if(r->in_exec) {
                if(r->exec_cycles > 0) {
                    r->exec_cycles--;
                    if(r->exec_cycles == 0) {
                        r->in_exec = false;
                        r->is_result_ready = true; // ready for wb
                    }
                }
            }

            else if(!r->is_result_ready) {
                // try to start execution when ready + FU available
                if(r->op == LD) {
                    if(is_mem_available && r->Qj==0) {
                        r->A = r->Vj + r->A; // effective address (word index)
                        r->in_exec = true;
                        is_mem_available = false;
                        r->exec_cycles = LAT_LD-1;
                    }
                }
                else if(r->op == ST) {
                    if(is_mem_available && r->Qj==0 && r->Qk==0) {
                        r->A = r->Vj + r->A; // base + imm
                        r->in_exec = true;
                        is_mem_available = false;
                        r->exec_cycles = LAT_ST-1;
                    }
                }
                //add and sub share same res units
                else if(r->op == ADD || r->op == SUB) {
                    if(is_add_available && r->Qj==0 && r->Qk==0) {
                        r->in_exec = true;
                        is_add_available = false;
                        r->exec_cycles = (r->op == ADD ? LAT_ADD : LAT_SUB) - 1;
                    }
                }
                //mul and div share same res units
                else if(r->op == MUL || r->op == DIV) {
                    if(is_mul_available && r->Qj==0 && r->Qk==0) {
                        r->in_exec = true;
                        is_mul_available = false;
                        r->exec_cycles = (r->op == MUL ? LAT_MUL : LAT_DIV) - 1;
                    }
                }
            }
        }
    }
     //step 1 appears to be done
    /********************************
     *     Step I: Issue
     ********************************/


    /*  wait if no RS entry is available */
    if(num_issued_inst < NUM_OF_INST) {
      int cand_rs_id;
      if(inst[num_issued_inst].op==ADD) cand_rs_id = obtain_available_rs(ADD_RS);
      else if(inst[num_issued_inst].op==SUB) cand_rs_id = obtain_available_rs(ADD_RS);
      else if(inst[num_issued_inst].op==MUL) cand_rs_id = obtain_available_rs(MUL_RS);
      else if(inst[num_issued_inst].op==DIV) cand_rs_id = obtain_available_rs(MUL_RS);
      else if(inst[num_issued_inst].op==LD) cand_rs_id = obtain_available_rs(LD_BUF);
      else if(inst[num_issued_inst].op==ST) cand_rs_id = obtain_available_rs(ST_BUF);

      /* if there is an available RS entry */
      if(cand_rs_id!=-1) {
        /* issue the instruction: See Fig. 3.13 */
	RS * curr_rs = get_rs(cand_rs_id);
        if(curr_rs ==NULL) {
          printf("NO RS found with the given id\n");
          exit(1);
        }

        /* normal ALU operations */
        if(inst[num_issued_inst].op==ADD || inst[num_issued_inst].op==SUB ||
          inst[num_issued_inst].op== MUL ||  inst[num_issued_inst].op==DIV) {
          int rd, rs, rt;
          rd = inst[num_issued_inst].rd;
          rs = inst[num_issued_inst].rs;
          rt = inst[num_issued_inst].rt;

          /* Rs */
          if(regs[rs].Qi!=0) curr_rs->Qj = regs[rs].Qi;
          else curr_rs->Vj = regs[rs].val;

          /* Rt */
          if(regs[rt].Qi!=0) curr_rs->Qk = regs[rt].Qi;
          else curr_rs->Vk = regs[rt].val;

          /* set busy */
          curr_rs->is_busy = true;
          curr_rs->op = inst[num_issued_inst].op;

          /* register update */
          regs[rd].Qi = curr_rs->id;

          /* set exec cycles */
          if(inst[num_issued_inst].op==ADD) curr_rs->exec_cycles=LAT_ADD;
          else if(inst[num_issued_inst].op==SUB) curr_rs->exec_cycles=LAT_SUB;
          else if(inst[num_issued_inst].op==MUL) curr_rs->exec_cycles=LAT_MUL;
          else if(inst[num_issued_inst].op==DIV) curr_rs->exec_cycles=LAT_DIV;

          /* num issued ++ */
          num_issued_inst++;

        } else if (inst[num_issued_inst].op==LD) {

          int rd, rs, imm;
          rd = inst[num_issued_inst].rd;
          rs = inst[num_issued_inst].rs;
          imm = inst[num_issued_inst].rt;

          /* Rs */
          if(regs[rs].Qi!=0) curr_rs->Qj = regs[rs].Qi;
          else curr_rs->Vj = regs[rs].val;

          /* addr */
          curr_rs->A = imm;

          /* set busy */
          curr_rs->is_busy = true;
          curr_rs->op = inst[num_issued_inst].op;

          /* set exec cycles */
          curr_rs->exec_cycles=LAT_LD;

          /* register update */
          regs[rd].Qi = curr_rs->id;

          /* num issued ++ */
          num_issued_inst++;

        } else if (inst[num_issued_inst].op==ST) {

          int rd, rs, imm;
          rd = inst[num_issued_inst].rd;
          rs = inst[num_issued_inst].rs;
          imm = inst[num_issued_inst].rt;

          /* Rs */
          if(regs[rs].Qi!=0) curr_rs->Qj = regs[rs].Qi;
          else curr_rs->Vj = regs[rs].val;

          /* Rd */
          if(regs[rd].Qi!=0) curr_rs->Qk = regs[rd].Qi;
          else curr_rs->Vk = regs[rd].val;

          /* addr */
          curr_rs->A = imm;

          /* set busy */
          curr_rs->is_busy = true;
          curr_rs->op = inst[num_issued_inst].op;

          /* set exec cycles */
          curr_rs->exec_cycles=LAT_ST;

          /* num issued ++ */
          num_issued_inst++;

        }
      }
    }


    /* print out the result */
    printf("* CYCLE %d\n",cycle);
    print_rs();
    print_regs();

    /* check the termination condition */
    if( (num_issued_inst>=NUM_OF_INST) && !is_rs_active())
      done =1;
  }
  return 0;
}
